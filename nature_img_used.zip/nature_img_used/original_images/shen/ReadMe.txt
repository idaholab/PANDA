Original images were: 
200kV_500kx_p2nm_8cmCL_grain1_0111  
1ROI_100kx_4100CL_foil1 


200kV_500kx_p2nm_8cmCL_grain1_0111  was cropped into 4 smaller images for ease of labeling
The 4 smaller images were also copied and color contrasted in PowerPoint resulting in 8 images of 200kV_500kx_p2nm_8cmCL_grain1_0111 .

